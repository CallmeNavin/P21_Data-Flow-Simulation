Entobel_Data_Simulation_v1

Files:
1) Operational_Data.xlsx
   - Sheet 'Biological': batch-level biological/feeding metrics
   - Sheet 'Processing': batch-level processing outputs and energy

2) MES_Data.xlsx
   - Sheet 'SensorLog': time-series sensor data (3 readings per batch on date_start)

3) Accounting_Data.xlsx
   - Sheet 'Costs': batch-level cost breakdown and total cost

4) Logistics_Data.xlsx
   - Sheet 'Shipments': batch-level shipment details

Suggested Power Automate flow (OneDrive → CSV → Master):
- Trigger: When a file is created in a folder (OneDrive/SharePoint)
- Actions:
  * Convert Excel to CSV
  * Append CSV content into a Master CSV (per domain)
  * Write a log entry (file name, upload time)
- Output: Master_Operational.csv, Master_MES.csv, Master_Accounting.csv, Master_Logistics.csv

Power BI steps:
- Load master CSV(s) (or the Excel files directly for practice)
- Create relationships via batch_id (and timestamp for MES if needed)
- Example Measures:
  * Feed_Efficiency = SUM(Processing[yield_dry_kg]) / SUM(Biological[feed_input_kg])
  * Cost_per_kg = SUM(Accounting[total_cost_usd]) / SUM(Processing[yield_dry_kg])

Notes:
- Data are simulated for learning. Any resemblance to real production is coincidental.
- Batch IDs: B001..B020, Dates: 2025-09-01..2025-09-20
